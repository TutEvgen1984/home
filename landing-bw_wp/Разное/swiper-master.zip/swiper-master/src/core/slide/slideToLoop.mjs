export default function slideToLoop(index = 0, speed, runCallbacks = true, internal) {
  if (typeof index === 'string') {
    const indexAsNumber = parseInt(index, 10);

    index = indexAsNumber;
  }
  const swiper = this;
  if (swiper.destroyed) return;

  if (typeof speed === 'undefined') {
    speed = swiper.params.speed;
  }

  const gridEnabled = swiper.grid && swiper.params.grid && swiper.params.grid.rows > 1;
  let newIndex = index;
  if (swiper.params.loop) {
    if (swiper.virtual && swiper.params.virtual.enabled) {
      // eslint-disable-next-line
      newIndex = newIndex + swiper.virtual.slidesBefore;
    } else {
      let targetSlideIndex;
      if (gridEnabled) {
        const slideIndex = newIndex * swiper.params.grid.rows;
        targetSlideIndex = swiper.slides.find(
          (slideEl) => slideEl.getAttribute('data-swiper-slide-index') * 1 === slideIndex,
        ).column;
      } else {
        targetSlideIndex = swiper.getSlideIndexByData(newIndex);
      }

      const cols = gridEnabled
        ? Math.ceil(swiper.slides.length / swiper.params.grid.rows)
        : swiper.slides.length;

      const { centeredSlides, slidesOffsetBefore, slidesOffsetAfter } = swiper.params;
      const bothDirections = centeredSlides || !!slidesOffsetBefore || !!slidesOffsetAfter;
      let slidesPerView = swiper.params.slidesPerView;
      if (slidesPerView === 'auto') {
        slidesPerView = swiper.slidesPerViewDynamic();
      } else {
        slidesPerView = Math.ceil(parseFloat(swiper.params.slidesPerView, 10));
        if (bothDirections && slidesPerView % 2 === 0) {
          slidesPerView = slidesPerView + 1;
        }
      }
      let needLoopFix = cols - targetSlideIndex < slidesPerView;
      if (bothDirections) {
        needLoopFix = needLoopFix || targetSlideIndex < Math.ceil(slidesPerView / 2);
      }
      if (internal && bothDirections && swiper.params.slidesPerView !== 'auto' && !gridEnabled) {
        needLoopFix = false;
      }

      if (needLoopFix) {
        const direction = bothDirections
          ? targetSlideIndex < swiper.activeIndex
            ? 'prev'
            : 'next'
          : targetSlideIndex - swiper.activeIndex - 1 < swiper.params.slidesPerView
          ? 'next'
          : 'prev';
        swiper.loopFix({
          direction,
          slideTo: true,
          activeSlideIndex:
            direction === 'next' ? targetSlideIndex + 1 : targetSlideIndex - cols + 1,
          slideRealIndex: direction === 'next' ? swiper.realIndex : undefined,
        });
      }

      if (gridEnabled) {
        const slideIndex = newIndex * swiper.params.grid.rows;
        newIndex = swiper.slides.find(
          (slideEl) => slideEl.getAttribute('data-swiper-slide-index') * 1 === slideIndex,
        ).column;
      } else {
        newIndex = swiper.getSlideIndexByData(newIndex);
      }
    }
  }

  requestAnimationFrame(() => {
    swiper.slideTo(newIndex, speed, runCallbacks, internal);
  });
  return swiper;
}
